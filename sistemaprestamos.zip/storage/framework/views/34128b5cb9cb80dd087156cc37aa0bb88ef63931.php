

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12 col-lg-8 offset-lg-2">
                        <div class="widget">
                            <header class="widget-header">
                                <h4 class="widget-title">Estadistica</h4>
                            </header><!-- .widget-header -->
                            <hr class="widget-separator">
                            <div class="widget-body">
                                <form method="POST" action="<?php echo e(url('history')); ?>" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label for="wallet"> Cartera:</label>
                                        <input type="text" name="wallet" value="<?php echo e($wallet->name); ?>" readonly class="form-control" id="wallet" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="average">Promedio Recaudado:</label>
                                        <input type="text" name="average" value="<?php echo e($summary); ?>" readonly class="form-control" id="average" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="sell">Promedio Ventas:</label>
                                        <input type="text" name="sell" readonly value="<?php echo e($credit); ?>" class="form-control" id="sell" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="sell">Promedio Gastos:</label>
                                        <input type="text" name="sell" readonly value="<?php echo e($bills); ?>" class="form-control" id="sell" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="days">Cantidad días:</label>
                                        <input type="text" name="days" value="<?php echo e($days); ?>" readonly class="form-control" id="days" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="days">Fechas:</label>
                                        <input type="text" name="days" value="<?php echo e($range); ?>" readonly class="form-control" id="days" required>
                                    </div>
                                </form>

                            </div><!-- .widget-body -->
                        </div><!-- .widget -->
                    </div><!-- END column -->
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\Laravel\sistema-prestamos\resources\views/supervisor_statistics/show.blade.php ENDPATH**/ ?>