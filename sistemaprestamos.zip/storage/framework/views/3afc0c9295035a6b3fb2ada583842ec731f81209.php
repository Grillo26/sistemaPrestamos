

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12 col-lg-8 offset-lg-2">
                        <div class="widget">
                            <header class="widget-header">
                                <h4 class="widget-title">Cierre</h4>
                            </header><!-- .widget-header -->
                            <hr class="widget-separator">
                            <div class="widget-body">
                                <form method="GET" action="<?php echo e(url('supervisor/menu/close')); ?>/<?php echo e(app('request')->input('id_wallet')); ?>" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="nit_number"> Selecciona fecha:</label>
                                        <input type="text" name="date_start"  class="form-control datepicker-trigger" id="date_start" data-role="date" required>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success btn-block btn-md">Buscar</button>
                                    </div>
                                </form>

                            </div><!-- .widget-body -->
                        </div><!-- .widget -->
                    </div><!-- END column -->
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\Laravel\sistema-prestamos\resources\views/submenu/close/create.blade.php ENDPATH**/ ?>