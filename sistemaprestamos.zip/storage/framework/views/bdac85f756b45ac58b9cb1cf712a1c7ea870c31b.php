

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12 col-lg-8 offset-lg-2">
                        <div class="widget">
                            <hr class="widget-separator">
                            <div class="widget-body">
                                <form method="POST" action="<?php echo e(url('supervisor/client')); ?>" class="supervisor-client" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label for="country"> Pais:</label>
                                        <select name="country" class="form-control" id="country">
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="wallet"> Cartera:</label>
                                        <select name="wallet" class="form-control" id="wallet">
                                            <option selected>Selecionar ....</option>
                                            <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($w->id); ?>"><?php echo e($w->name); ?> (<?php echo e($w->user_name); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group hidden">
                                        <label for="agent"> Agente:</label>
                                        <select name="agent" class="form-control" id="agent">
                                            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?> <?php echo e($a->last_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <!--<button type="submit" class="hidden btn btn-success btn-block btn-md">Guardar</button>-->
                                        <a id="link_client_audit" class="btn btn-success btn-block" disabled href="<?php echo e(url('supervisor/review')); ?>">Revisar</a>
                                    </div>
                                </form>

                            </div><!-- .widget-body -->
                        </div><!-- .widget -->
                    </div><!-- END column -->
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\Laravel\sistema-prestamos\resources\views/supervisor_review/create.blade.php ENDPATH**/ ?>