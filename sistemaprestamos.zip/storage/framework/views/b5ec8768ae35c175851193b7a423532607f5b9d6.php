

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Gastos</h4>
                            <form class="form-inline" action="<?php echo e(url('bill')); ?>" method="GET">
                                <div class="form-group hidden">
                                    <label for="nit_number"> Fecha Inicial:</label>
                                    <input type="text" name="date_start"  class="form-control datepicker-trigger" id="date_start" required>
                                </div>
                                <div class="form-group hidden">
                                    <label for="nit_number"> Fecha Final:</label>
                                    <input type="text" name="date_end"  class="form-control datepicker-trigger" id="date_end" required>
                                </div>
                                <div class="form-group">
                                    <label for="pwd">Categoria:</label>
                                    <select name="category" required id="" class="form-control">
                                        <?php $__currentLoopData = $list_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="">Todos</option>
                                    </select>
                                </div>
                                 <button class="btn btn-info hidden" type="submit">Buscar</button>
                                <a href="<?php echo e(url('bill/create')); ?>" class="btn btn-success">Nuevo Gasto</a>

                            </form>
                            <br class="clearfix">
                            <table class="table agente-g-table">
                                <thead>
                                <tr class="visible-lg">
                                    <th>Cartera</th>
                                    <th>Fecha</th>
                                    <th>Valor</th>
                                    <th>Detalle</th>
                                    <th>Categoría</th>
                                    <th>Agente</th>
                                    <th></th>
                                </tr>
                            </thead>
                                <tbody>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->wallet_name); ?></td>
                                        <td><?php echo e($client->created_at); ?></td>

                                        <td><?php echo e($client->amount); ?></td>
                                        <td><?php echo e($client->description); ?></td>
                                        <td><?php echo e($client->category_name); ?></td>
                                        <td><?php echo e($client->user_name); ?></td>

                                        <td></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                            <footer class="widget-footer">
                                <p><b>Total: </b><span class="text-success"><?php echo e($total); ?></span></p>
                            </footer>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\Laravel\sistema-prestamos\resources\views/bill/index.blade.php ENDPATH**/ ?>