

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Clientes y Creditos</h4>
                            <table class="table supervisor-route-table">
                                <thead>
                                <tr class="visible-lg">
                                    <th>Credito</th>
                                    <th>Nombres</th>
                                    <th>Fecha de prestamos</th>
                                    <th>Cuota diaria</th>
                                    <th>Dias sin pagar</th>
                                    <th>Valor</th>
                                    <th>Saldo</th>
                                    <th>Barrio</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->id); ?></td>
                                        <td><?php echo e($client->user->name); ?> <?php echo e($client->user->last_name); ?></td>
                                        <td><?php echo e($client->created_at); ?></td>
                                        <td><?php echo e($client->quote); ?></td>
                                        <td><?php echo e($client->rest_days); ?></td>
                                        <td><?php echo e($client->amount_neto); ?></td>
                                        <td><?php echo e($client->saldo); ?></td>
                                        <td><?php echo e($client->user->province); ?></td>
                                        <td>
                                            <?php if($client->user->status=='good'): ?>
                                                <span class="badge-info badge">BUENO</span>
                                            <?php elseif($client->user->status=='bad'): ?>
                                                <span class="badge-danger badge">MALO</span>
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('supervisor/menu/history')); ?>/<?php echo e($client->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-history"></i> Ver</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
                <div class="col-lg-12 text-right">
                    <a href="<?php echo e(url('supervisor/review/')); ?>/<?php echo e($id_wallet); ?>" class="btn btn-inverse"><i class="fa fa-arrow-left"></i> Regresar</a>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\Laravel\sistema-prestamos\resources\views/submenu/route/index.blade.php ENDPATH**/ ?>