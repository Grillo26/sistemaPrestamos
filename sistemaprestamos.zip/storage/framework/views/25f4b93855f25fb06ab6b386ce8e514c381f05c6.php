

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Creditos Otorgados kk</h4>
                            <table class="table supervisor-creditos-table">
                                <thead>
                                <tr class="visible-lg">
                                    <th>Nombres</th>
                                    <th>Credito</th>
                                    <th>Barrio</th>
                                    <th>Hora</th>
                                    <th>Tasa</th>
                                    <th>Cuotas</th>
                                    <th>Valor neto</th>
                                </tr>
                            </thead>
                                <tbody>
                                <?php $__currentLoopData = $credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($cred->name); ?> <?php echo e($cred->last_name); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->credit_id); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->province); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->created_at); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->utility); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->payment_number); ?></span></td>
                                        <td><span class="value"><?php echo e(($cred->amount_neto)); ?></span></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody></table>
                            <footer class="widget-footer">
                                <p><b>Total: </b><span class="text-success"><?php echo e($total_credit); ?></span></p>
                            </footer>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Pagos Recibidos</h4>
                            <table class="table supervisor-payments-table">
                                <thead>
                                <tr class="visible-lg">
                                    <th>Nombres</th>
                                    <th>Fecha</th>
                                    <th>Credito</th>
                                    <th>Cuota</th>
                                    <th>Valor</th>
                                    <th>Saldo</th>
                                </tr>
                            </thead>
                                <tbody>
                                <?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($sum->name); ?> <?php echo e($sum->last_name); ?></span></td>
                                        <td><span class="value"><?php echo e($sum->created_at); ?></span></td>
                                        <td><span class="value"><?php echo e($sum->credit_id); ?></span></td>
                                        <td><span class="value"><?php echo e($sum->number_index); ?></span></td>
                                        <td><span class="value"><?php echo e($sum->amount); ?></span></td>
                                        <td><span class="value"><?php echo e((($sum->amount_neto)+($sum->amount_neto*$sum->utility))-($sum->total_summary)); ?></span></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                            <footer class="widget-footer">
                                <p><b>Total: </b><span class="text-success"><?php echo e($total_summary); ?></span></p>
                            </footer>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Gastos del Agente</h4>
                            <table class="table supervisor-gas-table">
                                <thead>
                                <tr class="visible-lg">
                                    <th>Gasto</th>
                                    <th>Detalle</th>
                                    <th>Valor</th>
                                    <th>Fecha</th>
                                </tr>
                            </thead>
                                <tbody>
                                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($bill->type_bill); ?></span></td>
                                        <td><span class="value"><?php echo e($bill->description); ?></span></td>
                                        <td><span class="value"><?php echo e($bill->amount); ?></span></td>
                                        <td><span class="value"><?php echo e($bill->created_at); ?></span></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                            <footer class="widget-footer">
                                <p><b>Total: </b><span class="text-success"><?php echo e($total_bills); ?></span></p>
                            </footer>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
                <div class="col-lg-12 text-right">
                    <a href="<?php echo e(url('supervisor/review/')); ?>/<?php echo e($id_wallet); ?>" class="btn btn-inverse"><i class="fa fa-arrow-left"></i> Regresar</a>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\Laravel\sistema-prestamos\resources\views/submenu/transitions/index.blade.php ENDPATH**/ ?>